﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class Ilac
    {
        public int ID { get; set; }
        public string ADI { get; set; }
        public int ADET { get; set; }
        public string SERINO { get; set; }



    }
}
