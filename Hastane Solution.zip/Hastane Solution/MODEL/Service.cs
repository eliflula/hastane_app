﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class Service
    {

        public int ID { get; set; }
        public string ADI { get; set; }
        public string ADRES { get; set; }


        
       

    }
}
