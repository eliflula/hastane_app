﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class Doctor
    {
        

        public Doctor()
        {
            
        }
        public string Name { get; set; }
        public string Surname { get; set; }
        public int PolId { get; set; }

    }
}
