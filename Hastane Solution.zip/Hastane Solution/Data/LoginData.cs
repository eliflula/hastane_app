﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    public class LoginData
    {
        private const string KullaniciAdi = "admin";
        private const string Sifre = "11111";

        public string getKullaniciAdi()
        {
            return KullaniciAdi;
        }

        public string getSifre()
        {
            return Sifre;
        }




    }
}
